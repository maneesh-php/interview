-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 28, 2020 at 09:47 AM
-- Server version: 5.7.25-0ubuntu0.18.04.2
-- PHP Version: 5.6.40-8+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coding_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dob` date DEFAULT NULL,
  `sunsign` varchar(255) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullname`, `gender`, `username`, `password`, `dob`, `sunsign`, `created_on`) VALUES
(1, 'Isi Desai', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Agis', '2020-06-28 03:08:16'),
(2, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16'),
(3, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16'),
(4, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16'),
(5, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16'),
(6, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16'),
(7, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16'),
(8, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16'),
(9, 'Lara Dutta', 'Female', 'maneesh', '827ccb0eea8a706c4c34a16891f84e7b', '2000-06-18', 'Sunrio', '2020-06-28 03:08:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
