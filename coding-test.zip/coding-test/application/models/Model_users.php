<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_users extends CI_Model {
    
   function userLogin()
    {  
       $u=trim($this->input->post('username'));
       $p=md5(trim($this->input->post('password')));
       $this -> db -> select('*');
       $this -> db -> from('user');
       $this -> db -> where('username',$u);
       $this -> db -> where('password',$p);
       $this -> db -> limit(1);
      $query = $this -> db -> get();
     if($query -> num_rows() == 1)
       {
         return $query->row();
       }
       else
       {
         return false;
       }
} 

public function addState($state){
    $data=array(
        'name' => trim($state)
    );
    return $this->db->insert('state',$data);
}  

public function addDistrict($data){
    $data=array(
        'state_id'=>$data['stateName'],
        'name' => trim($data['districtName'])
    );
    return $this->db->insert('district',$data);
}  


public function getState(){
    $this -> db -> select('*');
       $this -> db -> from('state');
       return $this -> db -> get()->result();
}

public function getPrfiles(){
    $this -> db -> select('*');
       $this -> db -> from('user');
       return $this -> db -> get()->result();
}

public function getDistrict(){
    $this->db->select('district.name as dname,state.name as sname')
         ->from('district')
         ->join('state', 'state.id = district.state_id','INNER');
       return $this -> db -> get()->result();
}


public function getDist($id){
       $this -> db -> select('*');
       $this -> db -> from('district');
       $this -> db -> where('state_id',$id);
       return $this -> db -> get()->result();
}

public function isUserExist($name){
        $this -> db -> select('*');
       $this -> db -> from('user');
       $this -> db -> where('lower(username)',strtolower($name));
       $res= $this -> db -> get()->row();
       if(count($res) > 0) {
              return $res->id;
       }
        return false;
       
}

public function checkDistrict($name){
        $this -> db -> select('*');
       $this -> db -> from('district');
        $this -> db -> where('lower(name)',strtolower($name));
       $res= $this -> db -> get()->row();

       if(count($res) > 0) {
             return $res->id;
       }
       
        return false;
       
}




public function viewChild($id){
    $this -> db -> select('*');
    $this -> db -> from('child');
    $this -> db -> where('id',$id);
    return $this -> db -> get()->row();
}


function register(){
     $data= $_POST;
      $data=array(
        'fullname'=>trim($data['firstname'])." ".trim($data['lastname']),
        'gender' => trim($data['optradio']),
        'username' => trim($data['username']),
        'password' => md5(trim($data['password'])),
        'dob' => date('Y-m-d',strtotime($data['dob'])),
        'sunsign' => trim($data['sunsign']),
    );
    return $this->db->insert('user',$data);
}


function uploadFIle()
    {       
        $this->load->library('upload');
        $config['upload_path'] = getcwd().'/uploads/'; 
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '1000';
        $config['max_width']  = '10024';
        $config['max_height']  = '7608';
        $this->upload->initialize($config);

        if ( ! $this->upload->do_upload('photo'))
        {
            $error = array('error' => $this->upload->display_errors());

            print_r($error); die;
        }
        else
        {
            //redirect('welcome/dashbord');
            $data = array('upload_data' => $this->upload->data());
        }
        $name=$data['upload_data']['file_name'];

        return $name;
    }
    
}

