<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Login</title>
     <link href="<?php echo base_url();?>assests/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="<?php echo base_url();?>assests/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assests/js/jquery.min.js"></script>


<style type="text/css">
    
    @import "bourbon";

body {
    background: #eee !important;    
}

.wrapper {  
    margin-top: 80px;
  margin-bottom: 80px;
}

.form-signin {
  max-width: 380px;
  padding: 15px 35px 45px;
  margin: 0 auto;
  background-color: #fff;
  border: 1px solid rgba(0,0,0,0.1);  

  .form-signin-heading,
    .checkbox {
      margin-bottom: 30px;
    }

    .checkbox {
      font-weight: normal;
    }

    .form-control {
      position: relative;
      font-size: 16px;
      height: auto;
      padding: 10px;
        @include box-sizing(border-box);

        &:focus {
          z-index: 2;
        }
    }

    input[type="text"] {
      margin-bottom: -1px;
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 0;
    }

    input[type="password"] {
      margin-bottom: 20px;
      border-top-left-radius: 0;
      border-top-right-radius: 0;
    }
}

</style>
    </head>
    <body>

      <div class="wrapper">
     
         <form id="login-form" name="login-form" class="form-signin" method="POST">     
 
         <div class="login-header">
        <h1>PWA</h1>
      </div>
      <?php 
$msg=false;
  if(!empty($this->session->flashdata('err')) || !empty($this->session->flashdata('succ'))){ $msg=true; ?>
    <?php if(!empty($this->session->flashdata('err'))){ ?>
        <p style="color: red;"><?=$this->session->flashdata('err');?></p>
    <?php } ?>
    <?php if(!empty($this->session->flashdata('succ'))){ ?>
        <p style="color: green;"><?=$this->session->flashdata('succ');?></p>
    <?php } ?>

  <?php } ?>
      <input type="text" class="form-control" name="username" id="username" placeholder="username" required="" autofocus="" />
       <br/> 
      <input type="password" class="form-control" name="password" id="password" placeholder="Password" required=""/>  
      <br/>    
      <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>   
      <p><a href="<?php echo base_url('user/register');?>">Sign Up<a></p>
    </form>
  </div>


    </body>
</html>
