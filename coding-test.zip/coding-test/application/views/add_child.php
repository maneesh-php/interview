<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 if(empty($user['user_id'])){
  redirect(base_url('login'));
 }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>State</title>
     <link href="<?php echo base_url();?>assests/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="<?php echo base_url();?>assests/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assests/js/jquery.min.js"></script>

    </head>
    <body >
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo base_url();?>"> <img width="50px" align="center" src="<?php echo base_url();?>logo.jpeg"  id="icon" alt="User Icon" style="ertical-align: middle;border-style: none;margin: 0 107px;"/></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo base_url('profile/state');?>">State</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/district');?>">District</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('profile/child');?>">Child</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('login/logout');?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>
<div class="wrapper">

         <form id="login-form" name="login-form" class="form-signin" method="POST" enctype="multipart/form-data">     
      <?php 
$msg=false;
  if(!empty($this->session->flashdata('err')) || !empty($this->session->flashdata('succ'))){ $msg=true; ?>
    <?php if(!empty($this->session->flashdata('err'))){ ?>
        <p style="color: red;"><?=$this->session->flashdata('err');?></p>
    <?php } ?>
    <?php if(!empty($this->session->flashdata('succ'))){ ?>
        <p style="color: green;"><?=$this->session->flashdata('succ');?></p>
    <?php } ?>

  <?php } ?>
      <input type="text" class="form-control" name="name" id="name" placeholder="name" required="" autofocus="" />
       <br/> 
      <select  name="gender" id="gender" class="form-control">
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        </select> 
      <br/>   
       <input type="date" class="form-control" name="dob" id="dob" placeholder="DOB" required="" autofocus="" />
       <br/> 
       <input type="text" class="form-control" name="fname" id="fname" placeholder="father's name" required="" autofocus="" />
       <br/>
       <input type="text" class="form-control" name="mname" id="mname" placeholder="Mother's name" required="" autofocus="" />
       <br/>
       <select  name="stateName" id="stateName" class="form-control" onchange="getDist(this.value);">
        <option value="">Select</option>
        <?php foreach ($list as $value) { ?>
           <option value="<?php echo $value->id;?>"><?php echo $value->name;?></option>

        <?php } ?>
      </select><br>

       <select  name="districtName" id="districtName" class="form-control">
        <option value="">Select</option>
       
      </select><br>
        <h3>Upload Photo</h3>
       <input type="file" class="form-control" name="photo" id="photo" placeholder="" required="" autofocus="" />
       <br/>
      <button class="btn btn-lg btn-primary btn-block" type="submit">Save</button>   
    </form>
  </div>
<script type="text/javascript">
$(document).ready(function(){
 // getDist();
});

  function getDist(id){
        $.ajax({
                type: "POST",
                url: "<?php echo base_url('profile/getDist');?>",
                data: {'state' : id},
                success: function(msg) {
                  $("#districtName").html(msg);
                }
            });
        return false;
  }
  
 function addState(){
  $("#stateName").css("border-color","");
     var state = $.trim($("#stateName").val());
        if(state==""){
          $("#stateName").css("border-color","red");
        }else{

            $.ajax({
                type: "POST",
                url: "<?php echo base_url('profile/addstate');?>",
                data: {"stateName":state},
                success: function(msg) {
                    if(msg=='1')
                    {
                      $("#stateName").val('');
                      getState();
                      alert('state added');
                    }
                    else
                    {
                        alert('Server error');
                        return false;
                    }
                }
            });
        }
        return false;
    }
</script>
    </body>
</html>
