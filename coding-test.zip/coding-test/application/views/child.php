<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 if(empty($user['user_id'])){
  redirect(base_url('login'));
 }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Child</title>
     <link href="<?php echo base_url();?>assests/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">


      <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" id="bootstrap-css">



<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
    </head>
    <body >
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo base_url();?>"> <img width="50px" align="center" src="<?php echo base_url();?>logo.jpeg"  id="icon" alt="User Icon" style="ertical-align: middle;border-style: none;margin: 0 107px;"/></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/state');?>">State</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo base_url('profile/district');?>">District</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('profile/child');?>">Child</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('login/logout');?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>

<h3>Child List <a style="float: right;" href="<?php echo base_url('profile/addchild');?>">Add Child</a></h3>
<hr/>

<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Fathers name</th>
                <th>Mothers name</th>
                <th>State</th>
                <th>District</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

        	<?php if(count($list) > 0){ ?>
		<?php foreach($list as $value){ ?>

            <tr>
                <td><?php echo $value->name; ?></td>
                <td><?php echo $value->gender; ?></td>
                <td><?php echo $value->dob; ?></td>
                <td><?php echo $value->fname; ?></td>
                <td><?php echo $value->mname; ?></td>
                <td><?php echo $value->state; ?></td>
                <td><?php echo $value->district; ?></td>
                <td><a href="<?php echo base_url('profile/view/'.$value->id);?>">View</a></td>
            </tr>
             <?php } ?>
           <?php }else{ ?>
           	<tr><th colspan="6"> No records available.</th></tr>
           <?php } ?>

    </body>
</html>















