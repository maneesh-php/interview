<?php


if(count($list) > 0) { $i=1; ?>
<?php foreach ($list as $value) { ?>
  <div class="card w-25">
  <div class="card-body">
    <h5 class="card-title"><?php echo $i;?></h5>
    <p class="card-text">
      <?php echo $value->sname ;?>
    </p>
     <p class="card-text">
      <?php echo $value->dname ;?>
    </p>
    
  </div>
</div>
<?php $i++ ;} ?>

<?php }else{

  echo "No result found!!";
} ?>