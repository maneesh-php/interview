<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 if(empty($user['user_id'])){
  redirect(base_url('login'));
 }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Child</title>
     <link href="<?php echo base_url();?>assests/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">


      <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet" id="bootstrap-css">



<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	
	$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
    </head>
    <body >
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo base_url();?>"> <img width="50px" align="center" src="<?php echo base_url();?>logo.jpeg"  id="icon" alt="User Icon" style="ertical-align: middle;border-style: none;margin: 0 107px;"/></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/state');?>">State</a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="<?php echo base_url('profile/district');?>">District</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('profile/child');?>">Child</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('login/logout');?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>

<h3>Child details </h3>
<hr/>
<table>
        <thead>
          <tr>
                <td colspan="3"><img  width="100px" src="<?php echo(base_url('uploads/'.$viewchild->image));?>" /></td>
                
            </tr>
            <tr>
                <td><b>Name : </b> <?php echo (isset($viewchild->name)? $viewchild->name : ''); ?></td>
                <td><b>Sex :</b> <?php echo (isset($viewchild->name)? $viewchild->gender : ''); ?></td>
                <td><b>Date of Birth :</b> <?php echo (isset($viewchild->dob)? $viewchild->name : ''); ?></td>
            </tr>
            <tr>
                <td><b>Father's Name :</b> <?php echo (isset($viewchild->dob)? $viewchild->name : ''); ?></td>
                <td><b>Mother's Name :</b> <?php echo (isset($viewchild->dob)? $viewchild->name : ''); ?></td>
                <td><b>Sate : </b><?php echo (isset($viewchild->dob)? $viewchild->name : ''); ?></td>
            </tr>
            <tr>
                <td><b>District :</b> <?php echo (isset($viewchild->dob)? $viewchild->name : ''); ?></td>
                
            </tr>
        </thead>
       
</table>
    </body>
</html>















