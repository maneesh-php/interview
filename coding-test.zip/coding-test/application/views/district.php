<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 if(empty($user['user_id'])){
  redirect(base_url('login'));
 }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>district</title>
     <link href="<?php echo base_url();?>assests/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="<?php echo base_url();?>assests/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assests/js/jquery.min.js"></script>

    </head>
    <body >
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo base_url();?>"> <img width="50px" align="center" src="<?php echo base_url();?>logo.jpeg"  id="icon" alt="User Icon" style="ertical-align: middle;border-style: none;margin: 0 107px;"/></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/state');?>">State</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo base_url('profile/district');?>">District</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/child');?>">Child</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('login/logout');?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>

<div class="card w-25">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
     <p class="card-text">
      <select  name="stateName" id="stateName" >
        <option value="">Select</option>
        <?php foreach ($list as $value) { ?>
           <option value="<?php echo $value->id;?>"><?php echo $value->name;?></option>

        <?php } ?>
      </select>
    </p>
    <p class="card-text">
      <input type="text" name="districtName" id="districtName" placeholder="Enter state name">
    </p>
    <a href="javascript:void();" onclick="addDistrict();" class="btn btn-primary">Add District</a>
  </div>
</div>
<div id="state-list" class="row">

</div>
<script type="text/javascript">
$(document).ready(function(){
  getDistrict();
});

  function getDistrict(){

        $.ajax({
                type: "POST",
                url: "<?php echo base_url('profile/getDistrict');?>",
                data: {},
                success: function(msg) {
                  $("#state-list").html(msg);
                }
            });
        return false;
  }
  
 function addDistrict(){
  $("#districtName,#stateName").css("border-color","");
     var districtName = $.trim($("#districtName").val());
     var stateName = $.trim($("#stateName").val());
     
        if(stateName==""){
          $("#stateName").css("border-color","red");
        }else if(districtName==""){
          $("#districtName").css("border-color","red");
        }else{

            $.ajax({
                type: "POST",
                url: "<?php echo base_url('profile/addDistrict');?>",
                data: {"districtName":districtName,'stateName':stateName},
                success: function(msg) {
                    if(msg=='1')
                    {
                      $("#districtName").val('');
                      getDistrict();
                      alert('district added');
                    }
                    else
                    {
                        alert('Server error');
                        return false;
                    }
                }
            });
        }
        return false;
    }
</script>
    </body>
</html>
