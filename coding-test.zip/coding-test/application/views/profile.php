<?php
defined('BASEPATH') OR exit('No direct script access allowed');

 if(empty($user['user_id'])){
  redirect(base_url('login'));
 }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Home</title>
     <link href="<?php echo base_url();?>assests/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="<?php echo base_url();?>assests/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assests/js/jquery.min.js"></script>

    </head>
    <body>

     <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php echo base_url();?>"> <img width="50px" align="center" src="<?php echo base_url();?>logo.jpeg"  id="icon" alt="User Icon" style="ertical-align: middle;border-style: none;margin: 0 107px;"/></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/state');?>">State</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/district');?>">District</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('profile/child');?>">Child</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url('login/logout');?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>

 <nav class="navbar navbar-expand-lg navbar-light bg-light">
 
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
     
      <li class="nav-item">
        <a class="nav-link" href="#">Name : <?php echo $user['fullname']; ?> </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Organization : <?php echo $user['organisation']; ?> </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Designation: <?php echo $user['designation']; ?> </a>
      </li>
      
    </ul>
  </div>
</nav>

<div id="carousel-example" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
  </ol>

  <div class="carousel-inner">
    <div class="item active">
      <a href="#"><img src="http://placekitten.com/1600/600" /></a>
      <div class="carousel-caption">
        <h3>Meow</h3>
        <p>Just Kitten Around</p>
      </div>
    </div>
 
  </div>

</div>
    </body>
</html>
