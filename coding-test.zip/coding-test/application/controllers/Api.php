<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_users');
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->library('form_validation');

		date_default_timezone_set("Asia/Kolkata");
	}


	public function user_login(){
		if($_SERVER["REQUEST_METHOD"] == "POST") {

			$request=file_get_contents('php://input');
			$data= $this->input->post();
			if(!empty($data['username']) && !empty($data['password'])){
					$res=$this->model_users->userLogin();
				if($res){
					$this->jsonresponse("success",null,"Logged in successfully.");
				}else{
					$this->jsonresponse("failed",null,"username or pasword is wrong.");
				}
				
				
			}else{
				$this->jsonresponse("failed",null,"Username and password is required!");
			}	
		}else{
			$this->jsonresponse("failed",null,"Invalid request!!");
		}
	}



	public function get_state(){
		if($_SERVER["REQUEST_METHOD"] == "GET") {
			$request=file_get_contents('php://input');
			$data= $this->input->post();
			$res=$this->model_users->getState();
			if(count($res) <= 0){
				$this->jsonresponse("failed",null,"No results found");
			}
			$this->jsonresponse("success",json_encode($res),"State listed.");
		}else{
			$this->jsonresponse("failed",null,"Invalid request!!");
		}
	}




public function addstate(){
	if($_SERVER["REQUEST_METHOD"] == "POST") {

		$request=file_get_contents('php://input');
		$data= $this->input->post();
	if(!empty($_POST['stateName'])){
				$res=$this->model_users->addState($_POST['stateName']);
				if($res){
					$this->jsonresponse("success",null,$_POST['stateName']. "is  added successfully.");
				}else{
					$this->jsonresponse("failed",null,"Error occured while adding state");
				}
			}else{
				$this->jsonresponse("failed",null,"State name is required");
			}
	}else{
		$this->jsonresponse("failed",null,"Invalid request!!");
	}
}


public function adddistrict(){
	if($_SERVER["REQUEST_METHOD"] == "POST") {

		$request=file_get_contents('php://input');
		$data= $this->input->post();
	if(!empty($_POST['districtName']) && !empty($_POST['stateName'])){

				$exist=$this->model_users->checkSatate(trim($_POST['stateName']));
				if(!$exist){
					$this->jsonresponse("failed",null,"Given state is not exist in DB,Please add state first then add district.");
				}
				$res=$this->model_users->addDistrict($_POST);
				if($res){
					$this->jsonresponse("success",null,$_POST['districtName']. " is  added successfully.");
				}else{
					$this->jsonresponse("failed",null,"Error occured while adding district");
				}
			}else{
				$this->jsonresponse("failed",null,"State and district are required");
			}
	}else{
		$this->jsonresponse("failed",null,"Invalid request!!");
	}
}


	public function get_district(){
		if($_SERVER["REQUEST_METHOD"] == "GET") {
			$request=file_get_contents('php://input');
			$data= $this->input->post();
			$res=$this->model_users->getDistrict();
			if(count($res) <= 0){
				$this->jsonresponse("failed",null,"No results found");
			}
			$this->jsonresponse("success",json_encode($res),"District listed.");
		}else{
			$this->jsonresponse("failed",null,"Invalid request!!");
		}
	}


	public function get_child(){
		if($_SERVER["REQUEST_METHOD"] == "GET") {
			$request=file_get_contents('php://input');
			$data= $this->input->post();
			$res=$this->model_users->getChild();
			if(count($res) <= 0){
				$this->jsonresponse("failed",null,"No results found");
			}
			$this->jsonresponse("success",json_encode($res),"Childs listed.");
		}else{
			$this->jsonresponse("failed",null,"Invalid request!!");
		}
	}


public function addchild(){
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		$request=file_get_contents('php://input');
		$data= $this->input->post();
	if(!empty($_POST['name']) && !empty($_POST['gender']) && !empty($_POST['dob']) && !empty($_POST['fname']) && !empty($_POST['mname']) && !empty($_POST['stateName']) && !empty($_POST['districtName'])){
			$exist=$this->model_users->checkSatate(trim($_POST['stateName']));
				if(!$exist){
					$this->jsonresponse("failed",null,"Given state is not exist in DB,Please add state first then add child.");
				}
				$exist1=$this->model_users->checkDistrict(trim($_POST['districtName']));
				if(!$exist1){
					$this->jsonresponse("failed",null,"Given district is not exist in DB,Please add district first then add child.");
				}

					$res=$this->model_users->addchild();
				if($res){
					$this->jsonresponse("success",null," New child added successfully.");
				}else{
					$this->jsonresponse("failed",null,"Error occured while adding child");
				}
			}else{
				$this->jsonresponse("failed",null,"All fields are required");
			}
	}else{
		$this->jsonresponse("failed",null,"Invalid request!!");
	}
}


	public function user_logout(){
		if($_SERVER["REQUEST_METHOD"] == "GET") {
			$this->session->sess_destroy();	
			$this->jsonresponse("success",null,"User logout successfully.");
		}else{
			$this->jsonresponse("failed",null,"Invalid request!!");
		}
	}

	public function jsonresponse($status,$data=null,$msg=null){
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		header("Access-Control-Allow-Methods: POST");
		header("Access-Control-Max-Age: 3600");
		header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
		$data=array(
			"status" => $status,
			"data" => $data,
			"msg" => $msg,

	);
		echo json_encode($data); die;
	}
    
   
}
