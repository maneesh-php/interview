<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_users');
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->library('form_validation');

		date_default_timezone_set("Asia/Kolkata");
	}

    
    public function index() {
    	if($this->input->post()){
    		 $data = $this->input->post();
    		 if(!empty($data['username'])  && !empty($data['password'])){
    		 	$res=$this->model_users->userLogin();
				if($res){
					$users_session = array(
						'user_id'=>$res->id,
						'username'=>$res->username,
						'fullname'=>$res->fullname,
						'isAuser'=>TRUE,
						);
					 $this->session->set_userdata('users_session',$users_session);
					redirect(base_url('user/home'));
				}else{
					$this->session->set_flashdata('err', 'Username or password is incorrect!');
				redirect(base_url('user'));
				}
    		 }else{
    		 	$this->session->set_flashdata('err', 'All fields are required!.');
				redirect(base_url('user'));
    		 }
    		
    	}
        
        $this->load->view('login');
	}
	

	public function register() {
    	if($this->input->post()){
    		 $data = $this->input->post();
    		 if(!empty($data['firstname'])  && !empty($data['lastname']) && !empty($data['optradio']) && !empty($data['username']) && !empty($data['password']) ){
				if($this->model_users->isUserExist(trim($data['username']))){
					$this->session->set_flashdata('err', $data['username']. ' Username already taken!');
					redirect(base_url('user/register'));
				} 
				$res=$this->model_users->register();
				if($res){
					$this->session->set_flashdata('succ', 'Registered successfully!');
					redirect(base_url('user/register'));
				}else{
					$this->session->set_flashdata('err', 'Username or password is incorrect!');
				redirect(base_url('user/register'));
				}
    		 }else{
    		 	$this->session->set_flashdata('err', 'All fields are required!.');
				redirect(base_url('user/register'));
    		 }
    		
    	}
        
        $this->load->view('register');
    }

public function logout(){
	$this->session->sess_destroy();
 	redirect(base_url('user'));
}

public function home(){
		$user_id=$this->session->userdata['users_session']['user_id'];
		if(empty($user_id)){
			redirect(base_url());
		}

		$res['list']=$this->model_users->getPrfiles();			
		$this->load->view('home',$res);
}

}
