<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model_users');
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->library('form_validation');

		date_default_timezone_set("Asia/Kolkata");

		$user_id=$this->session->userdata['users_session']['user_id'];
			if(empty($user_id)){
				redirect(base_url('login'));
			}
	}

    
    public function index()
	{
		$data['user']=$this->session->userdata['users_session'];
		$this->load->view('profile',$data);
	}

	 public function state()
		{
			$data['user']=$this->session->userdata['users_session'];
			$this->load->view('state',$data);
		}


	 public function district()
		{
			$data['list']=$this->model_users->getState();	
			$data['user']=$this->session->userdata['users_session'];
			$this->load->view('district',$data);
		}

	 public function child()
		{
			$data['list']=$this->model_users->getChild();
			$data['user']=$this->session->userdata['users_session'];
			$this->load->view('child',$data);
		}

		public function addstate()
		{
			if($_POST){

				if(!empty($_POST['stateName'])){
					$res=$this->model_users->addState($_POST['stateName']);
					if($res){
						echo "1"; die;
					}
				}
			}
			echo "0"; die;
		}

		public function addDistrict()
		{
			if($_POST){

				if(!empty($_POST['districtName']) && !empty($_POST['stateName'])){
					$res=$this->model_users->addDistrict($_POST);
					if($res){
						echo "1"; die;
					}
				}
			}
			echo "0"; die;
		}
	
	public function getstate()
		{	
		  $res['list']=$this->model_users->getState();	
		   echo $this->load->view('ajax_state',$res,true); die;
		}


		public function getDistrict()
		{	
		  $res['list']=$this->model_users->getDistrict();	
		   echo $this->load->view('ajax_district',$res,true); die;
		}


		public function addchild()
		{
			if($_POST){
				
				if(!empty($_POST['name']) && !empty($_POST['gender']) && !empty($_POST['dob']) && !empty($_POST['fname']) && !empty($_POST['mname']) && !empty($_POST['stateName']) && !empty($_POST['districtName'])){
					$res=$this->model_users->addchild();
					if($res){
						redirect(base_url('profile/child'));
					}else{
						$this->session->set_flashdata('err', 'Something went wrong.');
					}
				}
				$this->session->set_flashdata('err', 'All fields are required!.');
			}
			$data['list']=$this->model_users->getState();
			$data['user']=$this->session->userdata['users_session'];
			$this->load->view('add_child',$data); 
		}

		public function getDist(){
			if(!empty($_POST['state'])){
				$data=$this->model_users->getDist($_POST['state']);
				if(count($data) > 0){
					$option ='<option value="">Select</option>';
					foreach ($data as $value) {
						$option = $option."<option value='".$value->id."'>".$value->name."</option>";
					}
					echo $option; die;
				}
			}
			echo "<option value=''>Select</option>"; die;
		}

public function view($id){
	$data['viewchild']=$this->model_users->viewChild($id);
	$data['user']=$this->session->userdata['users_session'];
	$this->load->view('child_detail',$data); 
}

}
